//
// aPLib compression library  -  the smaller the better :)
//
// C# wrapper
//
// Copyright (c) 1998-2009 by Joergen Ibsen / Jibz
// All Rights Reserved
//
// http://www.ibsensoftware.com/
//

using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("aPLib dll wrapper")]
[assembly: AssemblyDescription("C# wrapper for the aPLib dll")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ibsen Software")]
[assembly: AssemblyProduct("aPLib compression library")]
[assembly: AssemblyCopyright("Copyright (c) 1998-2009 by Joergen Ibsen. All Rights Reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
