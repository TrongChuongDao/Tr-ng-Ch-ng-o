# LuaP Browser by Warranty Voider

this tool allows to open, browse, edit and saveback lua bytecode for the xbox 360 version of the game "The Saboteur"

![preview](https://i.imgur.com/v5NyEqr.png)
