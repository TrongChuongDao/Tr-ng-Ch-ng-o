var objShell = new ActiveXObject("WScript.shell");
objShell.run('calc.exe');